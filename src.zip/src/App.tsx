import React from 'react'
import ReactDOM from 'react-dom'
import MyApp from './components/MyApp';


export default function() {
  return <MyApp />
}
//ReactDOM.render(<App />, document.getElementById('app'))





