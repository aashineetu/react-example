export function addTask(task:any){
  return {
  type: 'ADD_TASK',
  payload: task
  }  
  }
  

  