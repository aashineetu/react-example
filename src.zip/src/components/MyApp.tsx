import * as React from 'react';
import { useNavigate,BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from './Home';
import About from './About';
import Login from './Login';
import Profile from './Profile';
import Header from './Header';
import { logoutUser } from '../action/userAction';
import { useDispatch , useSelector} from "react-redux";
interface UserInfo {
  username: string;
  password: string;
}

interface User {
isAuthenticated: boolean;
 message: string;
 userInfo :UserInfo;
}

export default function MyApp()  {
    
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [user, setUser] = React.useState<User>();
    const reduxLoginData = useSelector((state:any) => state.user);

  const setAuthData= (user: User) => {    
    setUser(user);   
  }

  const logout =(event: React.MouseEvent<HTMLButtonElement>)  => {
   
    dispatch(logoutUser());
      if(localStorage.getItem("auth")
    ){
      localStorage.removeItem("auth");  
     
      //navigate("/login"); 
    }
      
  }
  

  
  
    return(
      <>           
                   
      {/* <Router> */}
      {/* <nav>
        <Link to="/">Home</Link><br/>    
        <Link to="/login">Login</Link><br/>        
        <Link to="/profile">Profile</Link><br/>
        <Link to="/about">About</Link><br/><br/>  
      </nav> */}
       <Header onLogout={logout} isAuthenticated={user.isAuthenticated} username={user && user.userInfo && user.userInfo.username}/>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login onLogin={setAuthData} onLogout={logout} color='red'/>} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/about" element={<About />} />
      </Routes>   
      <nav>
         
        <Link to="/login">Login</Link><br/>        
       
      </nav>    
    {/* </Router>                 */}

    </>
  )  ;

}