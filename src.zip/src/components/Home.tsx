import * as React from 'react';

export default function Hero( ) {   
    
    return(
      <>
      This is Home!!!

      </>
  )  ;

}