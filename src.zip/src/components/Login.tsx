import * as React from 'react';
import { render } from "@testing-library/react";
import { useEffect, useState } from "react";
import { useDispatch , useSelector} from "react-redux";
import 'bootstrap/dist/css/bootstrap.min.css';
import {addTask} from '../action/task';
import axios from "axios";
import UserInfo from './UserInfo'
import { loginUser,logoutUser } from '../action/userAction';
import { BrowserRouter as Router, Routes, Route, Link, Navigate } from "react-router-dom";
import Home from './Home';
import About from './About';

interface UserInfo {
  username: string;
  password: string;
}

interface User {
isAuthenticated: boolean;
 message: string;
 userInfo :UserInfo;
}

export interface LoginProps{  
  color: string;
  onLogin: Function;
  onLogout: Function;
  
}
export default function Login(props: LoginProps ) {
    const[color,setColor] = useState("yellow");    
    const[username,setUsername] =useState('');
    const[password,setPassword] =useState('');
    const userInfo = {
      username:"",
      password:"",      
    }
    const[loginFormData,setloginFormData] =useState(userInfo);

    const dispatch = useDispatch();
    const task = { color: 'blue', changeType: 'added' };
    const[result,setResult]:any=React.useState();
    const [user, setUser] = React.useState<User>();
    const reduxLoginData = useSelector((state:any) => state.user);

   // const isAuthenticated = useSelector((state:any) => state.user.isAuthenticated);
   // const message = useSelector((state:any) => state.user.message);


    console.log("hhhhhhhhhhhhhhhhhh" +color);
    React.useEffect(()=>{
      dispatch(addTask(task));
      console.log("hhhhhhhhhhhhhhhhhh" +color);
    })

    async function getUserInfo(){
      await axios.get("https://jsonplaceholder.typicode.com/posts")
       .then((res=>{         
         setResult(res.data);
         console.log("hhhhhhhhhhh" +typeof res.data);
     }));
    }
   useEffect(()=>{
      setColor("red")

    },[color]);

    useEffect(()=>{
        setColor("green");
  
      },[color]);    
    
      const captureValues = (event: any) =>{
        setloginFormData((prev)=>({
          ...prev,
          [event.target.name] : event.target.value
        }));
        
      }          

      
      const handleLogin = () => {
        dispatch(loginUser(loginFormData));       
       
      }

      const handleLogout = () => {        
        dispatch(logoutUser());
      }
      // useEffect(() => {
      //   if (user) {
      //   props.onLogin(user);
      //     localStorage.setItem("auth", JSON.stringify(user)); // Store session
      //   }
      // }, [user.isAuthenticated=true]);

         // Sync Redux state with local state
  React.useEffect(() => {
    setUser(reduxLoginData);    
  }, [reduxLoginData]); // Runs when Redux state updates
    
    return(
      <>
      <p>{color}</p>
      <button onClick={getUserInfo}>call me </button>    
      { 
      
      result && (

      <UserInfo data={result}/>
      )
      
      }      
    <div>
            {user.isAuthenticated && user !== null? (
                <div style={{textAlign:"center"}}>
                    <h2> {user.message}, {user && user.user && user.user.username}!</h2>
                   
                     <Navigate to="/profile" />;


                   
                </div>
            ) : (
              
              <div style={{textAlign:"center"}}>
              <h2>Login Form</h2>
              <p style={{color:"green"}}>{user.message}</p>
              User Name: <input type='text' name="username" value={loginFormData.username} onChange={captureValues}></input><br/>
              Password: <input type='text' name="password" value={loginFormData.password} onChange={captureValues}></input>
              <br/><br/>
                <div style={{textAlign:"center"}}><button onClick={handleLogin}>Login</button></div>
                </div>
            )}
        </div>

      </>
  )  ;

}